﻿import { generateAvatar } from '../lib/generateAvatar.js';
import config from '../config.cjs';

const avatarCmd = async (m, conn) => {
  const prefix = config.PREFIX;
  const args = m.body.slice(prefix.length).trim().split(/\s+/);
  const command = args[0].toLowerCase();
  const name = args[1] || "butterfly";
  const style = args[2] || "adventurer";

  if (!["avatar", "dicebear", "ppbot"].includes(command)) return;

  const avatarUrl = generateAvatar(name, style);

  const response = `
â•­â”ã€” DICEBEAR AVATAR ã€•â”â•®
â”ƒ ðŸ‘¤ *Name:* ${name}
â”ƒ ðŸŽ¨ *Style:* ${style}
â”ƒ ðŸ–¼ï¸ *Avatar:* [SVG Image]
â•°â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â•¯
> Â© BY DJOUSSE-TECH-MD
`;

  await conn.sendMessage(m.from, {
    image: { url: avatarUrl },
    caption: response
  }, { quoted: m });
};

export default avatarCmd;


