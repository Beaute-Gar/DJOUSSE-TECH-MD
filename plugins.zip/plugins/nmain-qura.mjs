﻿import axios from 'axios';
import config from '../config.cjs';

const quranMedia = async (m, gss) => {
  const prefix = config.PREFIX;
  const cmd = m.body.startsWith(prefix) ? m.body.slice(prefix.length).split(' ')[0].toLowerCase() : '';

  const videoCommands = ['quranvid', 'qvid', 'quranvideo'];
  const imageCommands = ['quraimage', 'qimg'];

  // â”€â”€â”€ ã€Ž Quran Video Command ã€ â”€â”€â”€ //
  if (videoCommands.includes(cmd)) {
    const videoUrl = 'https://bk9.fun/Islam/quranvid';
    await m.React('ðŸŒ™');

    await gss.sendMessage(
      m.from,
      {
        video: { url: videoUrl },
        caption:
`â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”“
â”ƒ  *ðŸ“– Ç«á´œÊ€á´€É´ á´ Éªá´…á´‡á´ á´‡xá´˜á´‡Ê€Éªá´‡É´á´„á´‡*  
â”ƒâ”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”
â”ƒ  *â€œA sound heart starts with divine verses.â€*
â”ƒ
â”ƒ  ðŸŒ€ *DJOUSSE-TECH-MD Exclusive Drop*
â”ƒ  ðŸ§  Mind â€¢ âœ¨ Soul â€¢ â¤ï¸ Peace
â”—â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”›`,
      },
      { quoted: m }
    );
  }

  // â”€â”€â”€ ã€Ž Quran Image Command ã€ â”€â”€â”€ //
  if (imageCommands.includes(cmd)) {
    const imageUrl = 'https://bk9.fun/Islam/din';
    await m.React('ðŸ•‹');

    await gss.sendMessage(
      m.from,
      {
        image: { url: imageUrl },
        caption:
`â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”“
â”ƒ  *ðŸ–¼ï¸ Ç«á´œÊ€á´€É´ Éªá´á´€É¢á´‡ á´ ÉªÊ™á´‡*
â”ƒâ”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”
â”ƒ  *â€œFaith isn't seen, it's felt.â€*
â”ƒ
â”ƒ  âš¡ *Coded by DJOUSSSE*
â”ƒ  â˜ï¸ Reflect â€¢ â˜€ï¸ Rise â€¢ ðŸ•Šï¸ Glow
â”—â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”›`,
      },
      { quoted: m }
    );
  }
};

export default quranMedia;

