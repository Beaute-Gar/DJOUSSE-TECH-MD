﻿import axios from 'axios';
import config from '../config.cjs';

const ipStalk = async (m, gss) => {
  const prefix = config.PREFIX;
  const cmd = m.body.startsWith(prefix) ? m.body.slice(prefix.length).split(' ')[0].toLowerCase() : '';
  const text = m.body.slice(prefix.length + cmd.length).trim();
  const args = text.split(' ');

  const validCommands = ['ipstalk', 'lookup', 'iplocate'];

  if (validCommands.includes(cmd)) {
    if (!args[0]) return m.reply('Mention an IP address to stalk.');

    const ip = args[0];

    const apiResponse = await axios.get(`https://bk9.fun/stalk/ip?q=${ip}`);
    const data = apiResponse.data;

    if (data.status) {
      const ipData = data.BK9;

      let responseMessage = `ðŸŒ *DJOUSSE-TECH-MD IP STALKER*\n\n`;
      responseMessage += `  â—¦  *IP*: ${ipData.ip}\n`;
      responseMessage += `  â—¦  *Continent*: ${ipData.continent}\n`;
      responseMessage += `  â—¦  *Country*: ${ipData.country} (${ipData.countryCode})\n`;
      responseMessage += `  â—¦  *Region*: ${ipData.regionName}\n`;
      responseMessage += `  â—¦  *City*: ${ipData.city}\n`;
      responseMessage += `  â—¦  *Zip Code*: ${ipData.zip}\n`;
      responseMessage += `  â—¦  *Latitude*: ${ipData.lat}\n`;
      responseMessage += `  â—¦  *Longitude*: ${ipData.lon}\n`;
      responseMessage += `  â—¦  *Timezone*: ${ipData.timezone}\n`;
      responseMessage += `  â—¦  *Currency*: ${ipData.currency}\n`;
      responseMessage += `  â—¦  *ISP*: ${ipData.isp}\n`;
      responseMessage += `  â—¦  *Organization*: ${ipData.org}\n`;
      responseMessage += `  â—¦  *AS*: ${ipData.as}\n`;
      responseMessage += `  â—¦  *Reverse DNS*: ${ipData.reverse}\n`;
      responseMessage += `  â—¦  *Mobile*: ${ipData.mobile ? 'Yes' : 'No'}\n`;
      responseMessage += `  â—¦  *Proxy*: ${ipData.proxy ? 'Yes' : 'No'}\n`;
      responseMessage += `  â—¦  *Hosting*: ${ipData.hosting ? 'Yes' : 'No'}\n\n`;
      responseMessage += `ðŸ”– *DJOUSSE-TECH-MD*\nðŸ”· *Ð²Ñƒ DJOUSSSE*\n`;

      await gss.sendMessage(m.from, { text: responseMessage }, { quoted: m });
    } else {
      m.reply(' IP address not found. Please check the input.');
    }
  }
};

export default ipStalk;

