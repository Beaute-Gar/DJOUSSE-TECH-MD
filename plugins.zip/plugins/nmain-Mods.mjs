﻿import config from '../config.cjs';

const modeCommand = async (m, Matrix) => {
  const botNumber = await Matrix.decodeJid(Matrix.user.id);
  const isCreator = [botNumber, config.OWNER_NUMBER + '@s.whatsapp.net', ...(config.SUDO || [])].includes(m.sender);
  const prefix = config.PREFIX;
  const cmd = m.body.startsWith(prefix) ? m.body.slice(prefix.length).split(' ')[0].toLowerCase() : '';
  const text = m.body.slice(prefix.length + cmd.length).trim();

  if (cmd !== 'mode') return;

  if (!isCreator) {
    return await Matrix.sendMessage(
      m.from,
      {
        text: `ðŸš« *ACCESS DENIED*\n\nðŸ“› This command is reserved for the *Owner* or *Sudo Users*.`,
      },
      { quoted: m }
    );
  }

  if (!text || !['public', 'private'].includes(text.toLowerCase())) {
    return await Matrix.sendMessage(
      m.from,
      {
        text: `â“ *Usage*\n\nâž¤ \`${prefix}mode public\`\nâž¤ \`${prefix}mode private\`\n\nðŸŒ Current mode: *${config.MODE || 'undefined'}*`,
      },
      { quoted: m }
    );
  }

  const selectedMode = text.toLowerCase();

  config.MODE = selectedMode;
  Matrix.public = selectedMode === 'public';

  return await Matrix.sendMessage(
    m.from,
    {
      text: `âœ… *Mode Updated*\n\nðŸ”„ Bot is now in *${selectedMode.toUpperCase()}* mode.`,
    },
    { quoted: m }
  );
};

export default modeCommand;

