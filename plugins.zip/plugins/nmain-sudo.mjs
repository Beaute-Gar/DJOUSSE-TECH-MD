﻿import config from '../config.cjs';

const ownerContact = async (m, gss) => {
    const ownernumber = config.SUDO_NUMBER;
    const prefix = config.PREFIX;
const cmd = m.body.startsWith(prefix) ? m.body.slice(prefix.length).split(' ')[0].toLowerCase() : '';
const text = m.body.slice(prefix.length + cmd.length).trim();

    if (cmd === 'sudo') {
        try {
            await gss.sendContact(m.from, [ownernumber], m);
            await m.React("âœ…");
        } catch (error) {
            console.error('Error sending owner contact:', error);
            m.reply('Error sending owner contact.');
            await m.React("âŒ");
        }
    }
};

export default ownerContact;

