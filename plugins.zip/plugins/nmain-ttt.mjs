﻿import config from '../config.cjs';

let tttGames = {};

const ttt = async (m, sock) => {
  const from = m.from;
  const sender = m.sender;
  const prefix = config.PREFIX || ".";

  const cmd = m.body.startsWith(prefix)
    ? m.body.slice(prefix.length).split(' ')[0].toLowerCase()
    : "";

  if (cmd === "ttt") {
    if (!tttGames[from]) {
      tttGames[from] = {
        playerX: sender,
        playerO: null,
        board: ["1ï¸âƒ£", "2ï¸âƒ£", "3ï¸âƒ£", "4ï¸âƒ£", "5ï¸âƒ£", "6ï¸âƒ£", "7ï¸âƒ£", "8ï¸âƒ£", "9ï¸âƒ£"],
        turn: "X",
      };
      return m.reply(`ðŸŽ® *Tic Tac Toe Created!*\nðŸ•¹ï¸ *${sender}* started a game.\nWaiting for a second player...\nType *${prefix}ttt* to join!`);
    }

    const game = tttGames[from];
    if (!game.playerO && sender !== game.playerX) {
      game.playerO = sender;
      const boardText = drawBoard(game.board);
      return sock.sendMessage(from, {
        text: `âœ… *Game Started!*\n${boardText}\nâŒ *${game.playerX}* vs â­• *${game.playerO}*\n\nðŸ”¥ *${game.playerX}*'s (âŒ) turn!`
      });
    }

    return m.reply("âš ï¸ Game already started. Please wait your turn.");
  }

  // Reset command
  if (cmd === "resetgame") {
    if (tttGames[from]) {
      delete tttGames[from];
      return m.reply("â™»ï¸ *Tic Tac Toe game has been reset!*");
    } else {
      return m.reply("âŒ No active game to reset.");
    }
  }

  // Ongoing game logic
  const game = tttGames[from];
  if (!game || !game.playerO) return;

  const validPlayers = [game.playerX, game.playerO];
  if (!validPlayers.includes(sender)) return;

  const move = m.body.trim();
  if (!/^[1-9]$/.test(move)) return;

  const pos = parseInt(move) - 1;
  if (game.board[pos] === "âŒ" || game.board[pos] === "â­•") {
    return m.reply("âŒ That spot is already taken!");
  }

  const symbol = game.turn === "X" ? "âŒ" : "â­•";
  const currentPlayer = game.turn === "X" ? game.playerX : game.playerO;

  if (sender !== currentPlayer) {
    return m.reply("â³ Not your turn!");
  }

  game.board[pos] = symbol;
  const boardText = drawBoard(game.board);

  const winner = checkWinner(game.board);
  if (winner) {
    await sock.sendMessage(from, {
      text: `ðŸ *Game Over!*\n${boardText}\nðŸ† Winner: *${currentPlayer}* (${symbol})`,
    });
    delete tttGames[from];
    return;
  }

  if (game.board.every(cell => cell === "âŒ" || cell === "â­•")) {
    await sock.sendMessage(from, {
      text: `ðŸ¤ *Draw!*\n${boardText}`,
    });
    delete tttGames[from];
    return;
  }

  game.turn = game.turn === "X" ? "O" : "X";
  const nextPlayer = game.turn === "X" ? game.playerX : game.playerO;
  const nextSymbol = game.turn === "X" ? "âŒ" : "â­•";

  await sock.sendMessage(from, {
    text: `ðŸŽ® *Next Turn!*\n${boardText}\nðŸ‘‰ *${nextPlayer}*'s (${nextSymbol}) move.`,
  });
};

function drawBoard(board) {
  return `

   ${board[0]}   â€¢   ${board[1]}   â€¢   ${board[2]}
   â€”â€”â€”â€”â€”â€”â€”â€”â€”â€”â€”
   ${board[3]}   â€¢   ${board[4]}   â€¢   ${board[5]}
   â€”â€”â€”â€”â€”â€”â€”â€”â€”â€”â€”
   ${board[6]}   â€¢   ${board[7]}   â€¢   ${board[8]}
`;
}

function checkWinner(b) {
  const winPatterns = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8],
    [0, 3, 6], [1, 4, 7], [2, 5, 8],
    [0, 4, 8], [2, 4, 6]
  ];
  for (const [a, b_, c] of winPatterns) {
    if (b[a] === b[b_] && b[b_] === b[c]) {
      return b[a];
    }
  }
  return null;
}

export default ttt;
      

