﻿import config from '../config.cjs';
import axios from 'axios';

const cricketScore = async (m, Matrix) => {
  const prefix = config.PREFIX;
const cmd = m.body.startsWith(prefix) ? m.body.slice(prefix.length).split(' ')[0].toLowerCase() : '';
const text = m.body.slice(prefix.length + cmd.length).trim();

  const validCommands = ['score', 'crick', 'crickterscore', 'cricket'];

  if (validCommands.includes(cmd)) {
    if (!text) {
      await m.React("âŒ");
      return m.reply(`*Provide a match ID for cricket score.*\nExample: ${prefix}cricketscore 12345`);
    }

    const matchId = encodeURIComponent(text);

    try {
      const apiUrl = `https://iol.apinepdev.workers.dev/${matchId}`;
      const response = await axios.get(apiUrl);

      if (!response.status === 200) {
        await m.React("âŒ");
        return m.reply(`Invalid response from the cricket score API. Status code: ${response.status}`);
      }

      const result = response.data;

      let formattedResult = `â•­â•â•â•â•â•â•â•â•â•â•â•â•â•â•â€¢âˆžâ€¢â•â•â•®\n`;
      formattedResult += `â”‚â¿»   *ðŸš€ DJOUSSE-TECH-MD*\n`;
      formattedResult += `â”‚â¿»   *LIVE MATCH INFO* âœ¨\n`;
      formattedResult += `â”‚â¿»\n`;

      if (result.code === 200) {
        formattedResult += `â”‚â¿»   *${result.data.title}*\n`;
        formattedResult += `â”‚â¿»   *${result.data.update}*\n`;
        formattedResult += `â”‚â¿» \n`;
      } else {
        await m.reply(`*Update:* Data not found for the specified match ID.`);
        await m.React("âŒ");
        return;
      }

      if (result.data.liveScore && result.data.liveScore.toLowerCase() !== "data not found") {
        formattedResult += `â”‚â¿»   *Live Score:* ${result.data.liveScore}\n`;
        formattedResult += `â”‚â¿»   *Run Rate:* ${result.data.runRate}\n`;
        formattedResult += `â”‚â¿»\n`;
        formattedResult += `â”‚â¿»   *Batter 1:* ${result.data.batsmanOne}\n`;
        formattedResult += `â”‚â¿»   *${result.data.batsmanOneRun} (${result.data.batsmanOneBall})* SR: ${result.data.batsmanOneSR}\n`;
        formattedResult += `â”‚â¿»\n`;
        formattedResult += `â”‚â¿»   *Batter 2:* ${result.data.batsmanTwo}\n`;
        formattedResult += `â”‚â¿»   *${result.data.batsmanTwoRun} (${result.data.batsmanTwoBall})* SR: ${result.data.batsmanTwoSR}\n`;
        formattedResult += `â”‚â¿»\n`;
        formattedResult += `â”‚â¿»   *Bowler 1:* ${result.data.bowlerOne}\n`;
        formattedResult += `â”‚â¿»   *${result.data.bowlerOneOver} overs, ${result.data.bowlerOneRun}/${result.data.bowlerOneWickets}, Econ:* ${result.data.bowlerOneEconomy}\n`;
        formattedResult += `â”‚â¿»\n`;
        formattedResult += `â”‚â¿»   *Bowler 2:* ${result.data.bowlerTwo}\n`;
        formattedResult += `â”‚â¿»   *${result.data.bowlerTwoOver} overs, ${result.data.bowlerTwoRun}/${result.data.bowlerTwoWicket}, Econ:* ${result.data.bowlerTwoEconomy}\n`;
      }

      formattedResult += `â•°â•â•â€¢âˆžâ€¢â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•¯ `;

      await m.reply(formattedResult);
      await m.React("âœ…");
    } catch (error) {
      console.error(error);
      await m.React("âŒ");
      return m.reply(`An error occurred while processing the cricket score request. ${error.message}`);
    }
  }
};

export default cricketScore;
      

