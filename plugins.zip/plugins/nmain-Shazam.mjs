﻿import fs from 'fs';
import acrcloud from 'acrcloud';
import config from '../config.cjs';


const acr = new acrcloud({
host: 'identify-eu-west-1.acrcloud.com',
access_key: '716b4ddfa557144ce0a459344fe0c2c9',
access_secret: 'Lz75UbI8g6AzkLRQgTgHyBlaQq9YT5wonr3xhFkf'
});

const shazam = async (m, gss) => {
  try {
    const prefix = config.PREFIX;
const cmd = m.body.startsWith(prefix) ? m.body.slice(prefix.length).split(' ')[0].toLowerCase() : '';
const text = m.body.slice(prefix.length + cmd.length).trim();

    const validCommands = ['shazam', 'hansfind', 'whatmusic'];
    if (!validCommands.includes(cmd)) return;
    
    const quoted = m.quoted || {}; 

    if (!quoted || (quoted.mtype !== 'audioMessage' && quoted.mtype !== 'videoMessage')) {
      return m.reply('You asked about music. Please provide a quoted audio or video message for identification.');
    }

    const mime = m.quoted.mimetype;
    try {
      const media = await m.quoted.download();
      const filePath = `./${Date.now()}.mp3`;
      fs.writeFileSync(filePath, media);

      m.reply('Identifying the music, please wait...');

      const res = await acr.identify(fs.readFileSync(filePath));
      const { code, msg } = res.status;

      if (code !== 0) {
        throw new Error(msg);
      }

      const { title, artists, album, genres, release_date } = res.metadata.music[0];
      const txt = `ðšð™´ðš‚ðš„ð™»ðšƒ 
      â€¢ ðŸ“Œ *TITLE*: ${title}
      â€¢ ðŸ‘¨â€ðŸŽ¤ ð™°ðšðšƒð™¸ðš‚ðšƒ: ${artists ? artists.map(v => v.name).join(', ') : 'NOT FOUND'}
      â€¢ ðŸ’¾ ð™°ð™»ð™±ðš„ð™¼: ${album ? album.name : 'NOT FOUND'}
      â€¢ ðŸŒ ð™¶ð™´ð™½ðšð™´: ${genres ? genres.map(v => v.name).join(', ') : 'NOT FOUND'}
      â€¢ ðŸ“† RELEASE DATE: ${release_date || 'NOT FOUND'}
      `.trim();

      fs.unlinkSync(filePath);
      m.reply(txt);
    } catch (error) {
      console.error(error);
      m.reply('An error occurred during music identification.');
    }
  } catch (error) {
    console.error('Error:', error);
    m.reply('An Error Occurred While Processing The Command.');
  }
};

export default shazam;
             

