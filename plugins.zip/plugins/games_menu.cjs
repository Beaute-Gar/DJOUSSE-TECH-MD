const { cmd } = require('../command.cjs');
const { box } = require('../lib/djousse-ui.cjs');

/* ═══════════════════════════════════════════════════════════════════════════
   GAMES MENU — Jeux copiés de N-main, adaptés au format CJS
   ═══════════════════════════════════════════════════════════════════════════ */

// ─── RPS (Pierre-Papier-Ciseaux) ────────────────────────────────────────
const rpsEmojis = { pierre: '🪨', papier: '📄', ciseaux: '✂️' };
const rpsWins = { pierre: 'ciseaux', papier: 'pierre', ciseaux: 'papier' };

cmd({
  pattern: 'rps',
  alias: ['rockpaperscissors', 'pierre'],
  react: '🎮',
  desc: 'Pierre-Papier-Ciseaux',
  category: 'fun',
  filename: __filename,
}, async (conn, m, commands, { q, reply }) => {
  if (!q) return reply('🎮 Utilisation: .rps pierre/papier/ciseaux');
  const player = q.toLowerCase().trim();
  if (!['pierre', 'papier', 'ciseaux'].includes(player)) return reply('❌ Choisis: pierre, papier ou ciseaux');
  const choices = ['pierre', 'papier', 'ciseaux'];
  const bot = choices[Math.floor(Math.random() * 3)];
  const emoji = rpsEmojis[player];
  const botEmoji = rpsEmojis[bot];
  let result;
  if (player === bot) result = '🤝 Match nul !';
  else if (rpsWins[player] === bot) result = '🏆 Tu gagnes !';
  else result = '😤 Tu perds !';
  await conn.sendMessage(m.chat, {
    text: box('🎮 *ROCK PAPER SCISSORS*', [
      { label: 'Toi', value: emoji + ' ' + player },
      { label: 'Bot', value: botEmoji + ' ' + bot },
      { blank: true },
      { raw: result },
    ]),
  }, { quoted: m });
});

// ─── MATH QUIZ ───────────────────────────────────────────────────────────
cmd({
  pattern: 'math',
  react: '🧮',
  desc: 'Quiz mathématique rapide',
  category: 'fun',
  filename: __filename,
}, async (conn, m, commands, { reply }) => {
  const ops = ['+', '-', '*'];
  const op = ops[Math.floor(Math.random() * ops.length)];
  const a = Math.floor(Math.random() * 20) + 1;
  const b = Math.floor(Math.random() * 20) + 1;
  const answer = eval(a + op + b);
  await conn.sendMessage(m.chat, {
    text: box('🧮 *MATH QUIZ*', [
      { raw: '*Combien fait:* ' + a + ' ' + op + ' ' + b + ' = ?' },
      { blank: true },
      { raw: '_Réponds avec le nombre_' },
    ]),
  }, { quoted: m });
  // Stocker la réponse pour vérification
  global._mathQuiz = global._mathQuiz || {};
  global._mathQuiz[m.chat] = { answer, timestamp: Date.now() };
});

// ─── HANGMAN (pendu simplifié) ───────────────────────────────────────────
const hangmanWords = ['whatsapp', 'bot', 'informatique', 'programmation', 'javascript', 'pizza', 'avion', 'chocolat', 'soleil', 'lundi'];

cmd({
  pattern: 'hangman',
  react: '🎯',
  desc: 'Jeu du pendu simplifié',
  category: 'fun',
  filename: __filename,
}, async (conn, m, commands, { q, reply }) => {
  const word = hangmanWords[Math.floor(Math.random() * hangmanWords.length)];
  const hidden = word.split('').map(() => '_').join(' ');
  const hint = word[0] + ' ' + word.slice(1).split('').map(() => '_').join(' ');
  await conn.sendMessage(m.chat, {
    text: box('🎯 *HANGMAN*', [
      { label: 'Mot', value: hidden },
      { label: 'Indice', value: hint },
      { label: 'Lettres', value: String(word.length) },
      { blank: true },
      { raw: '_Devine le mot en proposant des lettres_' },
    ]),
  }, { quoted: m });
  global._hangman = global._hangman || {};
  global._hangman[m.chat] = { word, found: [word[0]], attempts: 0 };
});

// ─── WHOAMI ──────────────────────────────────────────────────────────────
cmd({
  pattern: 'whoami',
  react: '👤',
  desc: 'Qui suis-je ? (devinette)',
  category: 'fun',
  filename: __filename,
}, async (conn, m, commands, { reply }) => {
  const facts = [
    'Tu es quelqu\'un de spécial. Ne l\'oublie jamais. ✨',
    'Tu es la meilleure version de toi-même. 🌟',
    'Tu es plus fort que tu ne le crois. 💪',
    'Tu es capable de grandes choses. 🚀',
    'Tu es unique en ton genre. 🦄',
    'Tu es une étoile dans la vie des autres. ⭐',
    'Tu es la raison pour laquelle quelqu\'un sourit aujourd\'hui. 😊',
    'Tu es la preuve que la gentillesse existe. 💛',
  ];
  const fact = facts[Math.floor(Math.random() * facts.length)];
  await conn.sendMessage(m.chat, {
    text: box('👤 *WHO AM I ?*', [
      { blank: true },
      { raw: fact },
    ]),
  }, { quoted: m });
});

// ─── SPEED TEST ──────────────────────────────────────────────────────────
cmd({
  pattern: 'speed',
  react: '⚡',
  desc: 'Tester la vitesse de réponse',
  category: 'fun',
  filename: __filename,
}, async (conn, m, commands, { reply }) => {
  const start = Date.now();
  await m.react('⚡').catch(() => {});
  const end = Date.now();
  const speed = end - start;
  await conn.sendMessage(m.chat, {
    text: box('⚡ *SPEED TEST*', [
      { label: 'Vitesse', value: speed + 'ms' },
      { label: 'Statut', value: speed < 200 ? '🚀 Ultra rapide' : speed < 500 ? '✅ Rapide' : '🐌 Lent' },
    ]),
  }, { quoted: m });
});

// ─── CHOOSE ──────────────────────────────────────────────────────────────
cmd({
  pattern: 'choose',
  react: '🔀',
  desc: 'Choisir entre plusieurs options',
  category: 'fun',
  filename: __filename,
}, async (conn, m, commands, { q, reply }) => {
  if (!q || !q.includes('|')) return reply('🔀 Utilisation: .choose option1 | option2 | option3');
  const options = q.split('|').map(o => o.trim()).filter(Boolean);
  const chosen = options[Math.floor(Math.random() * options.length)];
  await conn.sendMessage(m.chat, {
    text: box('🔀 *CHOIX ALÉATOIRE*', [
      { label: 'Options', value: options.join(' | ') },
      { blank: true },
      { raw: '*Choix:* ' + chosen },
    ]),
  }, { quoted: m });
});

// ─── COIN FLIP ───────────────────────────────────────────────────────────
cmd({
  pattern: 'flip',
  alias: ['coin'],
  react: '🪙',
  desc: 'Lancer une pièce',
  category: 'fun',
  filename: __filename,
}, async (conn, m, commands, { reply }) => {
  const result = Math.random() < 0.5 ? '🪙 Face !' : '🪙 Pile !';
  await conn.sendMessage(m.chat, {
    text: box('🪙 *COIN FLIP*', [
      { blank: true },
      { raw: result },
    ]),
  }, { quoted: m });
});

// ─── DICE ────────────────────────────────────────────────────────────────
cmd({
  pattern: 'dice',
  react: '🎲',
  desc: 'Lancer un dé',
  category: 'fun',
  filename: __filename,
}, async (conn, m, commands, { reply }) => {
  const result = Math.floor(Math.random() * 6) + 1;
  const dice = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'][result - 1];
  await conn.sendMessage(m.chat, {
    text: box('🎲 *DICE*', [
      { blank: true },
      { raw: dice + ' — ' + result },
    ]),
  }, { quoted: m });
});

// ─── TRIVIA ──────────────────────────────────────────────────────────────
const triviaQuestions = [
  { q: 'Quel est le plus grand océan ?', a: 'Pacifique', opts: ['Pacifique', 'Atlantique', 'Indien', 'Arctique'] },
  { q: 'Combien de pattes a une araignée ?', a: '8', opts: ['6', '8', '10', '12'] },
  { q: 'Quelle est la capitale du Japon ?', a: 'Tokyo', opts: ['Tokyo', 'Pékin', 'Séoul', 'Bangkok'] },
  { q: 'Quel gaz est le plus abondant dans l\'atmosphère ?', a: 'Azote', opts: ['Oxygène', 'Azote', 'CO2', 'Hydrogène'] },
  { q: 'Combien de continents y a-t-il ?', a: '7', opts: ['5', '6', '7', '8'] },
  { q: 'Qui a peint la Joconde ?', a: 'Léonard de Vinci', opts: ['Léonard de Vinci', 'Picasso', 'Monet', 'Rembrandt'] },
  { q: 'Quelle est la planète la plus proche du Soleil ?', a: 'Mercure', opts: ['Mercure', 'Vénus', 'Terre', 'Mars'] },
  { q: 'Quel est le plus grand pays du monde ?', a: 'Russie', opts: ['Chine', 'Russie', 'USA', 'Canada'] },
];

cmd({
  pattern: 'trivia',
  react: '🧠',
  desc: 'Quiz général aléatoire',
  category: 'fun',
  filename: __filename,
}, async (conn, m, commands, { reply }) => {
  const t = triviaQuestions[Math.floor(Math.random() * triviaQuestions.length)];
  const opts = t.opts.sort(() => Math.random() - 0.5).map((o, i) => (i + 1) + '. ' + o).join('\n');
  await conn.sendMessage(m.chat, {
    text: box('🧠 *TRIVIA*', [
      { raw: '*Question:* ' + t.q },
      { blank: true },
      { raw: opts },
      { blank: true },
      { raw: '_Réponds avec le numéro (1-4)_\nRéponse: *' + t.a + '*' },
    ]),
  }, { quoted: m });
});

// ─── CONNECT 4 ───────────────────────────────────────────────────────────
const connect4Games = {};
const EMPTY = '⚪';
const RED = '🔴';
const YELLOW = '🟡';

function createBoard() { return Array(6).fill(null).map(() => Array(7).fill(EMPTY)); }
function drawBoard4(board) { return board.map(row => row.join('')).join('\n'); }

function checkWin4(board, color) {
  const dirs = [[0,1],[1,0],[1,1],[1,-1]];
  for (let r = 0; r < 6; r++) for (let c = 0; c < 7; c++) {
    if (board[r][c] !== color) continue;
    for (const [dr, dc] of dirs) {
      let count = 0;
      for (let i = 0; i < 4; i++) {
        const nr = r + dr*i, nc = c + dc*i;
        if (nr<0||nr>=6||nc<0||nc>=7||board[nr][nc]!==color) break;
        count++;
      }
      if (count === 4) return true;
    }
  }
  return false;
}

cmd({
  pattern: 'connect4',
  react: '🔴',
  desc: 'Connect 4 en groupe',
  category: 'fun',
  filename: __filename,
}, async (conn, m, commands, { from, reply }) => {
  if (!connect4Games[from]) {
    connect4Games[from] = { board: createBoard(), players: [m.sender], turn: 0 };
    return reply('🎮 *Connect 4 lancé !*\nJoueur 2 tape .connect4 pour rejoindre.');
  }
  const g = connect4Games[from];
  if (!g.players.includes(m.sender) && g.players.length < 2) {
    g.players.push(m.sender);
    return reply('✅ *2ème joueur rejoint !*\n' + g.players[0] + ' (🔴) vs ' + g.players[1] + ' (🟡)\n\nUtilise .drop <1-7> pour jouer.\n' + drawBoard4(g.board));
  }
});

cmd({
  pattern: 'drop',
  react: '⬇️',
  desc: 'Placer un pion (Connect 4)',
  category: 'fun',
  filename: __filename,
}, async (conn, m, commands, { q, from, reply }) => {
  if (!connect4Games[from]) return;
  const g = connect4Games[from];
  if (g.players.length < 2) return reply('⏳ En attente d\'un joueur...');
  if (g.players[g.turn % 2] !== m.sender) return reply('⏳ Pas ton tour.');
  const col = parseInt(q) - 1;
  if (isNaN(col) || col < 0 || col > 6) return reply('❌ Colonne 1 à 7.');
  let placed = false;
  for (let row = 5; row >= 0; row--) {
    if (g.board[row][col] === EMPTY) { g.board[row][col] = g.turn % 2 === 0 ? RED : YELLOW; placed = true; break; }
  }
  if (!placed) return reply('❌ Colonne pleine.');
  const color = g.turn % 2 === 0 ? RED : YELLOW;
  if (checkWin4(g.board, color)) {
    const winner = g.players[g.turn % 2];
    delete connect4Games[from];
    return reply('🏆 *' + winner.split('@')[0] + ' gagne !*\n\n' + drawBoard4(g.board));
  }
  g.turn++;
  reply('🎮 *Tour:* ' + g.players[g.turn % 2].split('@')[0] + '\n\n' + drawBoard4(g.board));
});
