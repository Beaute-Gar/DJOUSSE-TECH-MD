// @legacy-order {"sourceFile":"03-protection/group3.js","sourceOrder":104,"definitionIndex":0,"entryOrder":285}
'use strict';
module.exports = {
  __legacyCommand: {"source":"_legacy-group3.js","sourceFile":"03-protection/group3.js","sourceOrder":104,"definitionIndex":0,"entryOrder":285,"names":["antipromote"]},
  commands: ["antipromote"],
  description: "Extended group management commands",
};
