// @legacy-order {"sourceFile":"05-outils/logo2.js","sourceOrder":136,"definitionIndex":0,"entryOrder":383}
'use strict';
module.exports = {
  __legacyCommand: {"source":"_legacy-logo2.js","sourceFile":"05-outils/logo2.js","sourceOrder":136,"definitionIndex":0,"entryOrder":383,"names":["summerbeach"]},
  commands: ["summerbeach"],
  description: "Logo maker and text effect generator",
};
